export const randomPage = () => {
    return Math.floor(Math.random() * 42) + 1;
}