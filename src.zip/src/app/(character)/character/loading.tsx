import Portal from '@/components/Portal/Portal'

export default function Loading() {
  return (
    <Portal mode='big' />
  )
}

